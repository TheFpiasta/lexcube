import { p as pako } from './pako.esm-856454b6.js';

const GZip = class GZip2 {
  static codecId = "gzip";
  level;
  constructor(level = 1) {
    if (level < 0 || level > 9) {
      throw new Error("Invalid gzip compression level, it should be between 0 and 9");
    }
    this.level = level;
  }
  static fromConfig({ level }) {
    return new GZip2(level);
  }
  encode(data) {
    const gzipped = pako.gzip(data, { level: this.level });
    return gzipped;
  }
  decode(data, out) {
    const uncompressed = pako.ungzip(data);
    if (out !== void 0) {
      out.set(uncompressed);
      return out;
    }
    return uncompressed;
  }
  decode3d(data, out) {
    return new Uint8Array();
  }
};

export { GZip as default };
