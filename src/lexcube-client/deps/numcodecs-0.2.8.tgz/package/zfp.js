import { z as zfp_codec, a as zfpWasmBinary } from './zfp_codec-64796c20.js';

const DEFAULT_TOLERANCE = -1;
const DEFAULT_PRECISION = -1;
const NX = 256;
const NY = 256;
const NZ = 256;
const BYTES_PER_FLOAT32 = 4;
const EXPECTED_BYTE_LENGTH_3D = NX * NY * NZ * BYTES_PER_FLOAT32;
const EXPECTED_BYTE_LENGTH_2D = NX * NY * BYTES_PER_FLOAT32;
let emscriptenModule;
const toArrayBufferBacked = (data) => {
  if (data.buffer instanceof ArrayBuffer) {
    return data;
  }
  return new Uint8Array(data);
};
const toArrayBuffer = (data) => {
  if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer) {
    return data.buffer;
  }
  const copied = toArrayBufferBacked(data);
  return copied.buffer.slice(copied.byteOffset, copied.byteOffset + copied.byteLength);
};
const init = () => zfp_codec({ noInitialRun: true, wasmBinary: toArrayBuffer(zfpWasmBinary) });
const Zfp = class Zfp2 {
  static codecId = "zfp";
  static DEFAULT_TOLERANCE = -1;
  static DEFAULT_PRECISION = -1;
  tolerance;
  precision;
  constructor(tolerance = DEFAULT_TOLERANCE, precision = DEFAULT_PRECISION) {
    if (!Number.isInteger(tolerance)) {
      throw Error(`Invalid tolerance "${tolerance}". Must be a positive integer.`);
    }
    if (!Number.isInteger(precision)) {
      throw Error(`Invalid precision "${precision}". Must be a positive integer.`);
    }
    this.tolerance = tolerance;
    this.precision = precision;
  }
  static fromConfig({ tolerance, precision }) {
    return new Zfp2(tolerance, precision);
  }
  async encode(data) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    const module = await emscriptenModule;
    const input = toArrayBufferBacked(data);
    if (input.byteLength !== EXPECTED_BYTE_LENGTH_2D) {
      throw Error(
        `Expecting a ${NX}x${NY} float32 block (${EXPECTED_BYTE_LENGTH_2D} bytes), got ${input.byteLength} bytes.`
      );
    }
    const view = module.compress(input, NX, NY, this.tolerance, this.precision);
    const result = new Uint8Array(view);
    module.free_result();
    return result;
  }
  async encode3d(data) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    const module = await emscriptenModule;
    const input = toArrayBufferBacked(data);
    if (input.byteLength !== EXPECTED_BYTE_LENGTH_3D) {
      throw Error(
        `Expecting a ${NX}x${NY}x${NZ} float32 block (${EXPECTED_BYTE_LENGTH_3D} bytes), got ${input.byteLength} bytes.`
      );
    }
    const view = module.compress3d(input, NX, NY, NZ, this.tolerance, this.precision);
    const result = new Uint8Array(view);
    module.free_result();
    return result;
  }
  async decode(data, out) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    const module = await emscriptenModule;
    const view = module.decompress(toArrayBufferBacked(data));
    if (out !== void 0) {
      if (out.byteLength !== EXPECTED_BYTE_LENGTH_2D) {
        throw Error(
          `Expecting an output size ${EXPECTED_BYTE_LENGTH_2D} bytes for ${NX}x${NY} float32, got ${out.byteLength} bytes.`
        );
      }
      out.set(view);
      module.free_result();
      return out;
    }
    const result = new Uint8Array(view);
    module.free_result();
    return result;
  }
  async decode3d(data, out) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    const module = await emscriptenModule;
    const view = module.decompress3d(toArrayBufferBacked(data));
    if (out !== void 0) {
      if (out.byteLength !== EXPECTED_BYTE_LENGTH_3D) {
        throw Error(
          `Expecting an output size ${EXPECTED_BYTE_LENGTH_3D} bytes for ${NX}x${NY}x${NZ} float32, got ${out.byteLength} bytes.`
        );
      }
      out.set(view);
      module.free_result();
      return out;
    }
    const result = new Uint8Array(view);
    module.free_result();
    return result;
  }
};

export { Zfp as default };
