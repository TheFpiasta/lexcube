export default class NumcodecsWorker {
    private worker;
    private nextId;
    private pending;
    ready: Promise<void>;
    constructor({ poolSize, worker }?: {
        poolSize?: number;
        worker?: Worker;
    });
    terminate(): void;
    /**
     * Return a ZFP output buffer (2D or 3D) to the worker's pool.
     * Only needed for the ZFP methods, which use preallocated buffers.
     */
    release(buffer: ArrayBuffer): void;
    zfpDecode(data: Uint8Array): Promise<Uint8Array>;
    zfpDecode3d(data: Uint8Array): Promise<Uint8Array>;
    lz4Decode(data: Uint8Array): Promise<Uint8Array>;
    bloscDecode(data: Uint8Array): Promise<Uint8Array>;
}
