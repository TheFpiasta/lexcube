import { l as lz4_codec, a as lz4WasmBinary } from './lz4_codec-ae48c195.js';

const DEFAULT_ACCELERATION = 1;
const MAX_BUFFER_SIZE = 2113929216;
const toArrayBufferBacked = (data) => {
  if (data.buffer instanceof ArrayBuffer) {
    return data;
  }
  return new Uint8Array(data);
};
const toArrayBuffer = (data) => {
  if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer) {
    return data.buffer;
  }
  const copied = toArrayBufferBacked(data);
  return copied.buffer.slice(copied.byteOffset, copied.byteOffset + copied.byteLength);
};
let emscriptenModule;
const init = () => lz4_codec({ noInitialRun: true, wasmBinary: toArrayBuffer(lz4WasmBinary) });
const LZ4 = class LZ42 {
  static codecId = "lz4";
  static DEFAULT_ACCELERATION = DEFAULT_ACCELERATION;
  static max_buffer_size = MAX_BUFFER_SIZE;
  max_buffer_size = MAX_BUFFER_SIZE;
  acceleration;
  constructor(acceleration = DEFAULT_ACCELERATION) {
    if (!Number.isInteger(acceleration)) {
      throw Error(`Invalid acceleration "${acceleration}". Must be a positive integer.`);
    }
    this.acceleration = acceleration <= 0 ? DEFAULT_ACCELERATION : acceleration;
  }
  static fromConfig({ acceleration }) {
    return new LZ42(acceleration);
  }
  async encode(data) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    if (data.length > MAX_BUFFER_SIZE) {
      throw Error(`Codec does not support buffers of > ${MAX_BUFFER_SIZE} bytes.`);
    }
    const module = await emscriptenModule;
    const input = toArrayBufferBacked(data);
    const view = module.compress(input, this.acceleration);
    const result = new Uint8Array(view);
    module.free_result();
    return result;
  }
  async decode(data, out) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    if (data.length > MAX_BUFFER_SIZE) {
      throw Error(`Codec does not support buffers of > ${MAX_BUFFER_SIZE} bytes.`);
    }
    const module = await emscriptenModule;
    const input = toArrayBufferBacked(data);
    const view = module.decompress(input);
    const result = new Uint8Array(view);
    module.free_result();
    if (out !== void 0) {
      out.set(result);
      return out;
    }
    return result;
  }
  async decode3d(data, out) {
    return new Uint8Array();
  }
};

export { LZ4 as default };
