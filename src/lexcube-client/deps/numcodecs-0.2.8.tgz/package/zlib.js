import { p as pako } from './pako.esm-856454b6.js';

const Zlib = class Zlib2 {
  static codecId = "zlib";
  level;
  constructor(level = 1) {
    if (level < -1 || level > 9) {
      throw new Error("Invalid zlib compression level, it should be between -1 and 9");
    }
    this.level = level;
  }
  static fromConfig({ level }) {
    return new Zlib2(level);
  }
  encode(data) {
    const gzipped = pako.deflate(data, { level: this.level });
    return gzipped;
  }
  decode(data, out) {
    const uncompressed = pako.inflate(data);
    if (out !== void 0) {
      out.set(uncompressed);
      return out;
    }
    return uncompressed;
  }
  decode3d(data, out) {
    return new Uint8Array();
  }
};

export { Zlib as default };
