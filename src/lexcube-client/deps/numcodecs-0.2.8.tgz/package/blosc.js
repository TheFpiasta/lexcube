import { b as blosc_codec, a as bloscWasmBinary } from './blosc_codec-55a9d42b.js';

const COMPRESSORS = /* @__PURE__ */ new Set(["blosclz", "lz4", "lz4hc", "snappy", "zlib", "zstd"]);
const toArrayBufferBacked = (data) => {
  if (data.buffer instanceof ArrayBuffer) {
    return data;
  }
  return new Uint8Array(data);
};
const toArrayBuffer = (data) => {
  if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer) {
    return data.buffer;
  }
  const copied = toArrayBufferBacked(data);
  return copied.buffer.slice(copied.byteOffset, copied.byteOffset + copied.byteLength);
};
let emscriptenModule;
const init = () => blosc_codec({ noInitialRun: true, wasmBinary: toArrayBuffer(bloscWasmBinary) });
const Blosc = class Blosc2 {
  static codecId = "blosc";
  static COMPRESSORS = [...COMPRESSORS];
  static NOSHUFFLE = 0 /* NOSHUFFLE */;
  static SHUFFLE = 1 /* SHUFFLE */;
  static BITSHUFFLE = 2 /* BITSHUFFLE */;
  static AUTOSHUFFLE = -1 /* AUTOSHUFFLE */;
  clevel;
  cname;
  shuffle;
  blocksize;
  constructor(clevel = 5, cname = "lz4", shuffle = 1 /* SHUFFLE */, blocksize = 0) {
    if (clevel < 0 || clevel > 9) {
      throw new Error(`Invalid compression level: '${clevel}'. It should be between 0 and 9`);
    }
    if (!COMPRESSORS.has(cname)) {
      throw new Error(
        `Invalid compressor '${cname}'. Valid compressors include
        'blosclz', 'lz4', 'lz4hc','snappy', 'zlib', 'zstd'.`
      );
    }
    if (shuffle < -1 || shuffle > 2) {
      throw new Error(
        `Invalid shuffle ${shuffle}. Must be one of 0 (NOSHUFFLE),
        1 (SHUFFLE), 2 (BITSHUFFLE), -1 (AUTOSHUFFLE).`
      );
    }
    this.blocksize = blocksize;
    this.clevel = clevel;
    this.cname = cname;
    this.shuffle = shuffle;
  }
  static fromConfig({ blocksize, clevel, cname, shuffle }) {
    return new Blosc2(clevel, cname, shuffle, blocksize);
  }
  async encode(data) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    const module = await emscriptenModule;
    const input = toArrayBufferBacked(data);
    const view = module.compress(input, this.cname, this.clevel, this.shuffle, this.blocksize);
    const result = new Uint8Array(view);
    module.free_result();
    return result;
  }
  async decode(data, out) {
    if (!emscriptenModule) {
      emscriptenModule = init();
    }
    const module = await emscriptenModule;
    const input = toArrayBufferBacked(data);
    const view = module.decompress(input);
    const result = new Uint8Array(view);
    module.free_result();
    if (out !== void 0) {
      out.set(result);
      return out;
    }
    return result;
  }
  async decode3d(data, out) {
    return new Uint8Array();
  }
};

export { Blosc as default };
