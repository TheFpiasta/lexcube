import { z as zfp_codec, a as zfpWasmBinary } from './zfp_codec-64796c20.js';
import { l as lz4_codec, a as lz4WasmBinary } from './lz4_codec-ae48c195.js';
import { b as blosc_codec, a as bloscWasmBinary } from './blosc_codec-55a9d42b.js';

const NX = 256;
const NY = 256;
const NZ = 256;
const BYTES_PER_FLOAT32 = 4;
const BYTES_2D = NX * NY * BYTES_PER_FLOAT32;
const BYTES_3D = NX * NY * NZ * BYTES_PER_FLOAT32;
const ctx = self;
let zfpModulePromise;
let lz4ModulePromise;
let bloscModulePromise;
let freeBuffers3d = [];
let freeBuffers2d = [];
let queue3d = [];
let queue2d = [];
const toArrayBuffer = (data) => {
  if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer) {
    return data.buffer;
  }
  const copied = new Uint8Array(data);
  return copied.buffer.slice(copied.byteOffset, copied.byteOffset + copied.byteLength);
};
const toZfpModule = async () => {
  if (!zfpModulePromise) {
    zfpModulePromise = zfp_codec({ noInitialRun: true, wasmBinary: toArrayBuffer(zfpWasmBinary) });
  }
  return zfpModulePromise;
};
const toLz4Module = async () => {
  if (!lz4ModulePromise) {
    lz4ModulePromise = lz4_codec({ noInitialRun: true, wasmBinary: toArrayBuffer(lz4WasmBinary) });
  }
  return lz4ModulePromise;
};
const toBloscModule = async () => {
  if (!bloscModulePromise) {
    bloscModulePromise = blosc_codec({ noInitialRun: true, wasmBinary: toArrayBuffer(bloscWasmBinary) });
  }
  return bloscModulePromise;
};
const post = (msg, transfer) => {
  if (transfer && transfer.length) {
    ctx.postMessage(msg, transfer);
  } else {
    ctx.postMessage(msg);
  }
};
const processQueues = async () => {
  const zfp = await toZfpModule();
  while (freeBuffers2d.length > 0 && queue2d.length > 0) {
    const { id, data, legacyType } = queue2d.shift();
    const outBuffer = freeBuffers2d.pop();
    try {
      const view = zfp.decompress(new Uint8Array(data));
      new Uint8Array(outBuffer).set(view);
      zfp.free_result();
      if (legacyType) {
        post({ type: "decoded", id, buffer: outBuffer }, [outBuffer]);
      } else {
        post({ type: "zfp_decoded", id, buffer: outBuffer }, [outBuffer]);
      }
    } catch (e) {
      post({ type: "error", id, message: String(e?.message ?? e) });
      freeBuffers2d.push(outBuffer);
    }
  }
  while (freeBuffers3d.length > 0 && queue3d.length > 0) {
    const { id, data, legacyType } = queue3d.shift();
    const outBuffer = freeBuffers3d.pop();
    try {
      const view = zfp.decompress3d(new Uint8Array(data));
      new Uint8Array(outBuffer).set(view);
      zfp.free_result();
      if (legacyType) {
        post({ type: "decoded3d", id, buffer: outBuffer }, [outBuffer]);
      } else {
        post({ type: "zfp_decoded3d", id, buffer: outBuffer }, [outBuffer]);
      }
    } catch (e) {
      post({ type: "error", id, message: String(e?.message ?? e) });
      freeBuffers3d.push(outBuffer);
    }
  }
};
ctx.onmessage = async (ev) => {
  const msg = ev.data;
  try {
    if (msg.type === "init") {
      const poolSize = Math.max(1, Math.floor(msg.poolSize ?? 2));
      await toZfpModule();
      freeBuffers3d = Array.from({ length: poolSize }, () => new ArrayBuffer(BYTES_3D));
      freeBuffers2d = Array.from({ length: poolSize }, () => new ArrayBuffer(BYTES_2D));
      queue3d = [];
      queue2d = [];
      post({ type: "ready", poolSize });
      return;
    }
    if (msg.type === "release") {
      if (msg.buffer.byteLength === BYTES_3D) {
        freeBuffers3d.push(msg.buffer);
      } else if (msg.buffer.byteLength === BYTES_2D) {
        freeBuffers2d.push(msg.buffer);
      } else {
        post({ type: "error", message: `release(): unexpected buffer size ${msg.buffer.byteLength}` });
      }
      void processQueues();
      return;
    }
    if (msg.type === "zfp_decode" || msg.type === "decode") {
      const legacyType = msg.type === "decode";
      if (freeBuffers2d.length === 0) {
        queue2d.push({ id: msg.id, data: msg.data, legacyType });
        return;
      }
      const zfp = await toZfpModule();
      const outBuffer = freeBuffers2d.pop();
      try {
        const view = zfp.decompress(new Uint8Array(msg.data));
        new Uint8Array(outBuffer).set(view);
        zfp.free_result();
        if (legacyType) {
          post({ type: "decoded", id: msg.id, buffer: outBuffer }, [outBuffer]);
        } else {
          post({ type: "zfp_decoded", id: msg.id, buffer: outBuffer }, [outBuffer]);
        }
      } catch (e) {
        post({ type: "error", id: msg.id, message: String(e?.message ?? e) });
        freeBuffers2d.push(outBuffer);
      }
      return;
    }
    if (msg.type === "zfp_decode3d" || msg.type === "decode3d") {
      const legacyType = msg.type === "decode3d";
      if (freeBuffers3d.length === 0) {
        queue3d.push({ id: msg.id, data: msg.data, legacyType });
        return;
      }
      const zfp = await toZfpModule();
      const outBuffer = freeBuffers3d.pop();
      try {
        const view = zfp.decompress3d(new Uint8Array(msg.data));
        new Uint8Array(outBuffer).set(view);
        zfp.free_result();
        if (legacyType) {
          post({ type: "decoded3d", id: msg.id, buffer: outBuffer }, [outBuffer]);
        } else {
          post({ type: "zfp_decoded3d", id: msg.id, buffer: outBuffer }, [outBuffer]);
        }
      } catch (e) {
        post({ type: "error", id: msg.id, message: String(e?.message ?? e) });
        freeBuffers3d.push(outBuffer);
      }
      return;
    }
    if (msg.type === "lz4_decode" || msg.type === "decode_lz4") {
      const legacyType = msg.type === "decode_lz4";
      const lz4 = await toLz4Module();
      try {
        const view = lz4.decompress(new Uint8Array(msg.data));
        const result = new Uint8Array(view);
        lz4.free_result();
        if (legacyType) {
          post({ type: "decoded_lz4", id: msg.id, buffer: result.buffer }, [result.buffer]);
        } else {
          post({ type: "lz4_decoded", id: msg.id, buffer: result.buffer }, [result.buffer]);
        }
      } catch (e) {
        post({ type: "error", id: msg.id, message: String(e?.message ?? e) });
      }
      return;
    }
    if (msg.type === "blosc_decode" || msg.type === "decode_blosc") {
      const legacyType = msg.type === "decode_blosc";
      const blosc = await toBloscModule();
      try {
        const view = blosc.decompress(new Uint8Array(msg.data));
        const result = new Uint8Array(view);
        blosc.free_result();
        if (legacyType) {
          post({ type: "decoded_blosc", id: msg.id, buffer: result.buffer }, [result.buffer]);
        } else {
          post({ type: "blosc_decoded", id: msg.id, buffer: result.buffer }, [result.buffer]);
        }
      } catch (e) {
        post({ type: "error", id: msg.id, message: String(e?.message ?? e) });
      }
      return;
    }
  } catch (e) {
    post({ type: "error", id: msg.id, message: String(e?.message ?? e) });
  }
};
