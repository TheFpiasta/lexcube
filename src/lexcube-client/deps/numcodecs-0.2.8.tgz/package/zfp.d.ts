import type { CodecConstructor } from './types';
interface ZfpConfig {
    tolerance?: number;
    precision?: number;
}
declare const Zfp: CodecConstructor<ZfpConfig>;
export default Zfp;
