const NX = 256;
const NY = 256;
const NZ = 256;
const BYTES_PER_FLOAT32 = 4;
const BYTES_2D = NX * NY * BYTES_PER_FLOAT32;
const BYTES_3D = NX * NY * NZ * BYTES_PER_FLOAT32;
const toTransferableBuffer = (data) => {
  if (data.byteOffset === 0 && data.byteLength === data.buffer.byteLength && data.buffer instanceof ArrayBuffer) {
    return data.buffer;
  }
  return new Uint8Array(data).buffer;
};
class NumcodecsWorker {
  worker;
  nextId = 1;
  pending = /* @__PURE__ */ new Map();
  ready;
  constructor({ poolSize = 2, worker } = {}) {
    this.terminate = this.terminate.bind(this);
    this.release = this.release.bind(this);
    this.zfpDecode = this.zfpDecode.bind(this);
    this.zfpDecode3d = this.zfpDecode3d.bind(this);
    this.lz4Decode = this.lz4Decode.bind(this);
    this.bloscDecode = this.bloscDecode.bind(this);
    this.worker = worker ?? new Worker(new URL("./numcodecs-worker-thread.js", import.meta.url), {
      type: "module"
    });
    this.worker.onmessage = (ev) => {
      const msg = ev.data;
      if (msg.type === "ready") {
        return;
      }
      if (msg.type === "error") {
        if (msg.id !== void 0) {
          const p2 = this.pending.get(msg.id);
          if (p2) {
            this.pending.delete(msg.id);
            p2.reject(new Error(msg.message));
          }
          return;
        }
        console.error(msg.message);
        return;
      }
      const p = this.pending.get(msg.id);
      if (!p) return;
      this.pending.delete(msg.id);
      p.resolve(msg.buffer);
    };
    this.ready = new Promise((resolve, reject) => {
      const onMsg = (ev) => {
        const msg = ev.data;
        if (msg.type === "ready") {
          this.worker.removeEventListener("message", onMsg);
          resolve();
        } else if (msg.type === "error" && msg.id === void 0) {
          this.worker.removeEventListener("message", onMsg);
          reject(new Error(msg.message));
        }
      };
      this.worker.addEventListener("message", onMsg);
      this.worker.postMessage({ type: "init", poolSize });
    });
  }
  terminate() {
    this.worker.terminate();
    this.pending.clear();
  }
  /**
   * Return a ZFP output buffer (2D or 3D) to the worker's pool.
   * Only needed for the ZFP methods, which use preallocated buffers.
   */
  release(buffer) {
    this.worker.postMessage({ type: "release", buffer }, [buffer]);
  }
  async zfpDecode(data) {
    await this.ready;
    const id = this.nextId++;
    const buf = toTransferableBuffer(data);
    const p = new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.worker.postMessage({ type: "zfp_decode", id, data: buf }, [buf]);
    });
    const out = await p;
    if (out.byteLength !== BYTES_2D) {
      throw new Error(`Worker returned unexpected ZFP 2D size ${out.byteLength}`);
    }
    return new Uint8Array(out);
  }
  async zfpDecode3d(data) {
    await this.ready;
    const id = this.nextId++;
    const buf = toTransferableBuffer(data);
    const p = new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.worker.postMessage({ type: "zfp_decode3d", id, data: buf }, [buf]);
    });
    const out = await p;
    if (out.byteLength !== BYTES_3D) {
      throw new Error(`Worker returned unexpected ZFP 3D size ${out.byteLength}`);
    }
    return new Uint8Array(out);
  }
  async lz4Decode(data) {
    await this.ready;
    const id = this.nextId++;
    const buf = toTransferableBuffer(data);
    const p = new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.worker.postMessage({ type: "lz4_decode", id, data: buf }, [buf]);
    });
    const out = await p;
    return new Uint8Array(out);
  }
  async bloscDecode(data) {
    await this.ready;
    const id = this.nextId++;
    const buf = toTransferableBuffer(data);
    const p = new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.worker.postMessage({ type: "blosc_decode", id, data: buf }, [buf]);
    });
    const out = await p;
    return new Uint8Array(out);
  }
}

export { NumcodecsWorker as default };
